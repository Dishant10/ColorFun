# README

Hey Apple,


My project ColorFunn is an iPad app and is all about fun with colours and chromesthesia.

There are some codes to enter in the last two section and you need to complete the previous tasks in order to move further. But to make the project viewing experience simpler and quicker, I'm providing you with the codes. 

The second, Grid section will give the first code. The left most bottom corner box is the one with the hint and the code to access the third section is AXR. (AXR).

In the third section and in the AR view the last right one that is the third one is the correct box and the code to enter the fourth section is CRX. (CRX).


The sound of different notes in the xylophone has been downloaded from publicly availbe sources and it contains to no rights or violation for an individual use.

The app icon has been made by me using the canva website hence it has not been downloaded or copied. 

I HOPE YOU ENJOY MY PROJECT. 
 
THANK YOU !!!!!!!




